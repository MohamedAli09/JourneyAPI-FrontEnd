// import React from "react";
import AllCards from "../AllCards/AllCards";

export default function Home() {
  return <AllCards />;
}
